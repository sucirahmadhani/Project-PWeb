module.exports = {
    'secret':'rahasia',
}