var express = require('express');
var auth = require('./auth');
const router = express.Router();
var verification = require('./verification')


router.post('/register', auth.registrasi);
router.post('/login', auth.login);
router.get('/login', (req,res) => {
    res.render('login')
})



// router.get('/rahasia', verification(2), auth.secretpage);

module.exports = router;