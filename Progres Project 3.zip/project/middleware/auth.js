var connection = require('../connection');
var mysql = require('mysql2');
var response = require('../response');
var jwt = require('jsonwebtoken');
var config = require('../config/secret');
var ip = require('ip'); 
var md5 = require('md5');
const user = require('../models/users')

/*Registrasi User*/
exports.registrasi = function (req, res) {
    var post = {
         username: req.body.username,
         email: req.body.email,
         password: req.body.password,
         active: req.body.active,
         sign_img:req.body.sign_img,
         created_at: new Date(),
         updated_at: new Date()
    }

    var query = "SELECT email FROM ?? WHERE ??=?";
    var table = ["users", "email", post.emai];

    query = mysql.format(query, table);

    connection.query(query, function (error, rows) {
        if (error) {
             console.log(error);
        }else{
            if(rows.length == 0){
                var query = "INSERT INTO ?? SET ?";
                var table = ["users"];
                query = mysql.format(query, table);
                connection.query(query, post, function(error, rows){
                    if(error){
                        console.log(error);
                    }else{
                        response.ok("Registration success", res);
                    }
                });
            }else{
                response.ok("email already registered", res);
            }
        }
    })
}

// Login User
exports.login = async (req, res) => {

    const email = req.body.email
    const password = req.body.password

    const findUser = await user.findOne({ //yg ini 
        where:{
            email:email
        }
    })

    const passwordmatch = findUser.password //ini ga

    if (!email || !password) {
        res.status(400).json({
            success: false, 
            message: 'Please Complete the form'
        })//copas berhasil 100 gagal 400
    } else {
        if (findUser) {
            if (password == passwordmatch) {
                res.status(200).json({
                    success: true,
                    message: 'Login Success'
                })
            } else {
                res.status(400).json({
                    success: false, 
                    message: 'Password is Wrong'
                })
            }
        } else {
            res.status(400).json({
                success: false,
                message: 'Email is Wrong'
            })
        }
    }
   
}


// jika admin web ingin dispesialkan
// exports.secretpage = function(req, res){
//     response.ok("Halaman ini hanya untuk user dengan role 2!",res)
// }

