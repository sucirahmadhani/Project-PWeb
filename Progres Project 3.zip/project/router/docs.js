var express = require('express');
const router = express.Router();
const document = require('../controllers/docs')

router.get('/document', document.document)
module.exports=router