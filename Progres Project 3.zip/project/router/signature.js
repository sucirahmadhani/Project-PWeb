var express = require('express');
const router = express.Router();
const signature = require('../controllers/signature')

router.get('/signature', signature.signature)
module.exports=router